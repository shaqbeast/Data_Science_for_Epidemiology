Q-1.1.py
No dependencies

Q-1.2.py
No dependencies

Q-1.3.py
No dependencies