Q-2.1.py
No dependencies. You would just need to change the k value within the code
on line 64.

Q-2.2.py
No dependencies

Q-2.3.py
No dependencies

Q-2.4.py
No dependencies

Q-2.5.py
No dependencies