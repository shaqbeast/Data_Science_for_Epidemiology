Q-3.1.py
No dependencies. Just make sure to change the covid data file on line 6
to whatever the data is located on your local laptop.

Q-3.2.py
No dependencies. Just make sure to change the covid data file on line 6
to whatever the data is located on your local laptop.

Q-3.3.py
No dependencies. Just make sure to change the covid data file on line 45
to whatever the data is located on your local laptop.