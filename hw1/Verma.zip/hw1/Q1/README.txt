Q-1.3.1:
No packages. If you'd like to change any variables, they're all labeled in the file

Q-1.3.2:
No packages. The path to open 'example.txt' will be different than the one in
the program. Please change this to your own local copy of 'example.txt' or copy 
the path for the same file in this folder.

Q-1.3.3:
No packages. The COVID file will be different than the one in
the program. Please change this to your own local copy or copy 
the path for the same file in this folder and paste it into the program.

Q-1.3.4:
No packages. You can change the values of N where it is labeled in the file.
