import numpy as np 
import csv
import networkx as nx 
from datetime import datetime
import matplotlib.pyplot as plt

# network array contains a list of tuples that show each edge that exists in the network
G = nx.DiGraph()
with open ('/Users/shaqbeast/CSE 8803 EPI/hw1/Q3/network.txt', mode='r') as file:
     for line in file:
        array_Nodes = line.strip().split()
        node1 = array_Nodes[0]
        node2 = array_Nodes[1]
        
        G.add_node(node1)
        G.add_node(node2)
        G.add_edge(node1, node2)

# ratings array contains a list of tuples that contain the date and movieIDs rated for each node/userID
# row[0] = userID
# row[1] = movieID

ratings = dict()
with open ('/Users/shaqbeast/CSE 8803 EPI/hw1/Q3/Ratings.timed.csv', mode='r') as file:
    csv_reader = csv.reader(file)
    header = next(csv_reader)
    for row in csv_reader:
        v_ID = int(row[0])
        movie_ID = int(row[1])
        date_string = row[3]
        date_object = datetime.strptime(date_string, "%Y/%m/%d %H:%M")
        key = v_ID
        value = (movie_ID, date_object)
        if key in ratings:
            ratings[key].append(value)
        else:
            ratings[key] = [value]

def calculate_pv(network, ratings):
    Av2u = 0
    Av = 0
    results = []
    
    # go through all nodes in the network
    for node in network.nodes():
        v_actions = ratings.get(int(node))
        if v_actions is None:
            Av = 0
        else:
            Av = len(v_actions)
        neighbors = list(network.neighbors(node))
        for neighbor_node in neighbors:
            u_actions = ratings.get(int(neighbor_node))
            Av2u = 0
            probability = 0
            if u_actions is not None and v_actions is not None:
                for v_tuple in v_actions:
                    v_movieID, v_date_time = v_tuple
                    for u_tuple in u_actions:
                        u_movieID, u_date_time = u_tuple
                        if ((v_movieID == u_movieID) and (v_date_time <= u_date_time)):
                            Av2u += 1
            else:
                Av2u = 0
            
            if Av == 0:
                probability = 0.0
            else: 
                probability = Av2u / Av
            tuple = (int(node), int(neighbor_node), probability)
            results.append(tuple)
            # print(tuple)
    
    return results
                        
                    
data = calculate_pv(G, ratings)
data_dict = dict()

for tuple in data:
    v, u, Pvu = tuple
    if v in data_dict:
        data_dict[v].append(Pvu)
    else:
        data_dict[v] = [Pvu]

# sum = 0
'''
for key in data_dict:
    # sum = 0
    for value in data_dict[key]:
        # sum += value
        plt.hist(value, bins=100, log=True)
'''
    
'''
# find the puv for each node
# add them up
# the final value gets added to the histogram
index = 0
sum = 0
for tuple in data:
    v, u, Pvu = tuple
    # if the index is not at the first edge
    if index > 0:
        previous_v, previous_u, previous_Pvu = data[index - 1]
        if v == previous_v:
            sum += Pvu
        else:
            print(sum)
            plt.hist(sum)
            # print(sum)
            sum = Pvu
    # 1st edge
    else:
        sum += Pvu

    index += 1
'''
#plot histogram
plt.hist(data_dict.values(), bins=5, log=True)
plt.title("Histogram for PU")
plt.xlabel("Probability")
plt.ylabel("Frequency(log scale)")
plt.show()

# output results into another csv file
header = ["v", "u", "probability"]
with open('Q3.2_output.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(header)
    
    writer.writerows(data)
    





"""
 # go through all the ratings 
    Av2u = 0
    Av = 0 # make sure to change to 0
    results = []
    total_index = 0 # keeps track of the row in the ratings array
    # vNode = None
    
    
    # go through all the nodes inside my network 
    # find the neighbors do that specific node 
    # go through the ratings array to try to find the v_node in the array
    # if it exists, increase Av += 1
    # else 
    # now go through the ratings array again to find the u_node 
    # go through all the nodes in the network
   for node in network.nodes():
        '''not sure where to reinitialize av'''
        Av = 0 
        Av2u = 0
        # find the neighbors of that network
        neighbors = list(network.neighbors(node))
        for neighbor_node in neighbors:
            # go through the entire ratings file and extract each row for v 
            for v_row in ratings:
                vID, v_movieID, v_date_time = v_row
            # see if the node in network has a place within the ratings file
                if (int(node) == vID):
                    # if it does, we increase Av by one since there's an action in the db
                    Av += 1
                    # go through the ratings file again
                    for u_row in ratings:
                        # extract the row to try to find the neighbor_node in the db
                        uID, u_movieID, u_date_time = u_row
                        # if the neighbor_node also exists in the db, we see if there's a valid cascade 
                        if (int(neighbor_node) == uID):
                            if (v_movieID == u_movieID):
                                if (v_date_time < u_date_time):
                                    # if there is we increase Av2u by 1
                                     Av2u += 1
            
            if (Av != 0):
                probability = Av2u / Av
            else:
                # if there's no value in the db for the node, then there's no valid cascade a prob = 0
                probability = 0
            tuple = (int(node), int(neighbor_node), probability)
            print(tuple)
            results.append(tuple)
            total_index += 1
    
    return results
"""



"""

    for row in ratings: 
        # save the values of the tuple in ratings into variables
        vID, v_movieID, v_date_time = row
        
        # once vID becomes a brand new ID, I need to reset Av2u = 0
        # if the vID = the previous row's userID, dont reset 
            
        # if we're not in the first row of ratings
        if (ratings[0] != row):
            
            previous_row = ratings[total_index - 1] 
            previous_vID = previous_row[0]
            # if we're still in the same userID
            if(vID == previous_vID):
                Av += 1
            else:
                Av2u = 0
                Av = 1
                
        # find the userID in the actual network
        # find the neighbors of that user and save it into an array
        for node in network.nodes():
            if int(node) == vID:
                vNode = node
                break          
            
        neighbors = list(network.neighbors(vNode))
        
        # find the movieIDs and times for the neighbors
        for neighbor_node in neighbors:
            # go through the ratings file again to find the neighbor node here
            for row in ratings:
                uID, u_movieID, u_date_time = row 
                # if this condition is true, we've found the neighbor's info in the ratings file
                if (int(neighbor_node) == uID):
                    # if the movie IDs are the same
                    if (v_movieID == u_movieID):
                        # 
                        if (v_date_time < u_date_time):
                            Av2u += 1
            
            probability = Av2u / Av
            tuple = (node, int(neighbor_node), probability)
            print(tuple)
            results.append(tuple)
            
            total_index += 1
                            
        
        # after the neighbors loop, I need to print out probability
"""


                            
    
                            
                            
                    
                
        
    
    