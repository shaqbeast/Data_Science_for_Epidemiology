Q-3.2
No packages. The ratings and network file will be different than the one in
the program. Please change this to your own local copy or copy 
the path for the same file in this folder and paste it into the program.

Output will go out to hw1/Q3.2_output.csv. The one in this directory
hw1/Q3/Q3.2_output.csv is a copy when I ran the code.